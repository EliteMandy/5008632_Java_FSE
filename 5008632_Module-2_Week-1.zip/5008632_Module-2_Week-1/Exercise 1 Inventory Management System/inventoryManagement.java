import java.util.*;

class Product {
    private int productId;
    private String productName;
    private int quantity;
    private double price;

    public Product(int productId, String productName, int quantity, double price) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product [productId=" + productId + ", productName=" + productName + ", quantity=" + quantity + ", price=" + price + "]";
    }
}

class InventoryManager {
    private Map<Integer, Product> inventory = new HashMap<>();
// Adding product in the inventory
    public void addProduct(Product product) {
        if (inventory.containsKey(product.getProductId())) {
            System.out.println("Product with ID " + product.getProductId() + " already exists.");
        } else {
            inventory.put(product.getProductId(), product);
            System.out.println("Product added: " + product);
            System.out.println("**************************");
        }
    }
// update existing product
    public void updateProduct(Product product) {
        if (inventory.containsKey(product.getProductId())) {
            inventory.put(product.getProductId(), product);
            System.out.println("Product updated: " + product);
            System.out.println("**************************");
        } else {
            System.out.println("Product with ID " + product.getProductId() + " does not exist.");
            System.out.println("**************************");
        }
    }
// deleting the product
    public void deleteProduct(int productId) {
        if (inventory.containsKey(productId)) {
            Product removedProduct = inventory.remove(productId);
            System.out.println("Product removed: " + removedProduct);
            System.out.println("**************************");
        } else {
            System.out.println("Product with ID " + productId + " does not exist.");
            System.out.println("**************************");
        }
    }

    public Product getProduct(int productId) {
        return inventory.get(productId);
    }
// inventoruy list
    public void displayAllProducts() {
        if (inventory.isEmpty()) {
            System.out.println("No products in inventory.");
            System.out.println("**************************");
        } else {
            System.out.println("Inventory:");
            for (Product product : inventory.values()) {
                System.out.println(product);
                System.out.println("**************************");
            }
        }
    }
}

public class inventoryManagement {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nInventory Management System Menu:");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product");
            System.out.println("3. Delete Product");
            System.out.println("4. Display All Products");
            System.out.println("5. Get Product Details");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter product ID: ");
                    int addProductId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter product name: ");
                    String addProductName = scanner.nextLine();
                    System.out.print("Enter product quantity: ");
                    int addQuantity = scanner.nextInt();
                    System.out.print("Enter product price: ");
                    double addPrice = scanner.nextDouble();
                    Product newProduct = new Product(addProductId, addProductName, addQuantity, addPrice);
                    manager.addProduct(newProduct);
                    break;

                case 2:
                    System.out.print("Enter product ID to update: ");
                    int updateProductId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new product name: ");
                    String updateProductName = scanner.nextLine();
                    System.out.print("Enter new product quantity: ");
                    int updateQuantity = scanner.nextInt();
                    System.out.print("Enter new product price: ");
                    double updatePrice = scanner.nextDouble();
                    Product updatedProduct = new Product(updateProductId, updateProductName, updateQuantity, updatePrice);
                    manager.updateProduct(updatedProduct);
                    break;

                case 3:
                    System.out.print("Enter product ID to delete: ");
                    int deleteProductId = scanner.nextInt();
                    manager.deleteProduct(deleteProductId);
                    break;

                case 4:
                    manager.displayAllProducts();
                    break;

                case 5:
                    System.out.print("Enter product ID to get details: ");
                    int getProductId = scanner.nextInt();
                    Product product = manager.getProduct(getProductId);
                    if (product != null) {
                        System.out.println("Product Details: " + product);
                    } else {
                        System.out.println("Product with ID " + getProductId + " not found.");
                    }
                    break;

                case 6:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
