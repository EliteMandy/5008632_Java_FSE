import java.util.Scanner;

class Order {
    private int orderId;
    private String customerName;
    private double totalPrice;

    public Order(int orderId, String customerName, double totalPrice) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.totalPrice = totalPrice;
    }

    public int getOrderId() {
        return orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    @Override
    public String toString() {
        return "Orders = " + "orderId=" + orderId + ", customerName='" + customerName + '\'' + ", totalPrice=" + totalPrice + '}';
    }
}

public class OrderSorting {
    public static void bubbleSort(Order[] orders) {
        int n = orders.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice()) {
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }

    public static void quickSort(Order[] orders, int low, int high) {
        if (low < high) {
            int pi = partition(orders, low, high);
            quickSort(orders, low, pi - 1);
            quickSort(orders, pi + 1, high);
        }
    }

    private static int partition(Order[] orders, int low, int high) {
        double pivot = orders[high].getTotalPrice();
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (orders[j].getTotalPrice() <= pivot) {
                i++;
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;
        return i + 1;
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the Size of the Order List");
        int size = scan.nextInt();
        Order[] orders = new Order[size];
        for (int i = 0; i < orders.length; i++) {
            System.out.print("Enter Order ID: ");
            int orderId = scan.nextInt();
            scan.nextLine();
            System.out.print("Enter Customer Name: ");
            String customerName = scan.nextLine();
            System.out.print("Enter Total Price: ");
            double totalPrice = scan.nextDouble();
            orders[i] = new Order(orderId, customerName, totalPrice);
        }

        while (true) {
            System.out.println("\nChoose sorting method:");
            System.out.println("1. Bubble Sort");
            System.out.println("2. Quick Sort");
            System.out.println("3. Exit");
            int choice = scan.nextInt();

            switch (choice) {
                case 1:
                    bubbleSort(orders);
                    System.out.println("Orders sorted using Bubble Sort:");
                    break;
                case 2:
                    quickSort(orders, 0, orders.length - 1);
                    System.out.println("Orders sorted using Quick Sort:");
                    break;
                case 3:
                    System.out.println("Exiting...");
                    scan.close();
                    return; // Exit the program
                default:
                    System.out.println("Invalid choice. Please select 1, 2, or 3.");
                    continue; // Go back to the sorting method selection
            }

            // Print sorted orders
            for (Order order : orders) {
                System.out.println(order);
            }
        }
    }
}