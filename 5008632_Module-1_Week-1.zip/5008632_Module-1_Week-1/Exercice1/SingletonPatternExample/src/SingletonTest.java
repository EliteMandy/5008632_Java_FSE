public class SingletonTest {
    public static void main(String[] args) {
        // Getting single instance of Logger
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();

        // Log messages through references
        logger1.log("This is a log message from logger1.");
        logger2.log("This is a log message from logger2.");

        // Check if the References are same or not
        System.out.println("Are logger1 and logger2 the same instance? " + (logger1 == logger2));
    }
}