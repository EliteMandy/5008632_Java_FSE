package com.example.commandpattern;

public interface Command {
    void execute();
}
