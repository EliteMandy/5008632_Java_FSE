package com.example.proxypattern;

public interface Image {
    void display();
}
