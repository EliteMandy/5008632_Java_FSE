package com.example.test;

import com.example.factory.DocumentFactory;
import com.example.factory.ConcreteDocumentFactory;
import com.example.documents.WordDocument;
import com.example.documents.PdfDocument;
import com.example.documents.ExcelDocument;

public class FactoryMethodPatternTest {
    public static void main(String[] args) {
        DocumentFactory factory = new ConcreteDocumentFactory();

        WordDocument wordDoc = factory.createWordDocument();
        wordDoc.open();

        PdfDocument pdfDoc = factory.createPdfDocument();
        pdfDoc.open();

        ExcelDocument excelDoc = factory.createExcelDocument();
        excelDoc.open();
    }
}
