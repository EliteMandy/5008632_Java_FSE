package com.example.documents.impl;

import com.example.documents.WordDocument;

public class ConcreteWordDocument implements WordDocument {
    @Override
    public void open() {
        System.out.println("Opening Word Document");
    }
}
