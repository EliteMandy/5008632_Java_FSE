package com.example.factory;

import com.example.documents.WordDocument;
import com.example.documents.PdfDocument;
import com.example.documents.ExcelDocument;
import com.example.documents.impl.ConcreteWordDocument;
import com.example.documents.impl.ConcretePdfDocument;
import com.example.documents.impl.ConcreteExcelDocument;

public class ConcreteDocumentFactory extends DocumentFactory {
    @Override
    public WordDocument createWordDocument() {
        return new ConcreteWordDocument();
    }

    @Override
    public PdfDocument createPdfDocument() {
        return new ConcretePdfDocument();
    }

    @Override
    public ExcelDocument createExcelDocument() {
        return new ConcreteExcelDocument();
    }
}
