package com.example.observerpattern;

public interface Observer {
    void update(double price);
}

